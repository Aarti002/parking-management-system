<footer>
    <div style="font-size:12px; text-align:left; display: inline-block; width:50%; color:silver;">
        Copyright &copy; 2020
	</div>
	<div style="font-size:12px; text-align:right; display: inline-block; width:49%; color:silver;">
		Vehicle Parking Management System
    </div>
</footer>